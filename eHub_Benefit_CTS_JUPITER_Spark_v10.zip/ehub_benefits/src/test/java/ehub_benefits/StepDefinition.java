package ehub_benefits;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Row;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.junit.Assert;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.remote.*;
//import org.testng.*;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

//import cts.mars.*;
//import org.sikuli.script.*;



public class StepDefinition {
	
	String[][] returnTD = new String[1000][10];
	SparkSession sparkSess;
	
	Date javaBatchProcessTime; //TC3
	Date rawOpLoadTime; //TC3
	//final String TS_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	SimpleDateFormat TsFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
	
	@Given("^Test Data is in RECEIVED state in CS90_CONTRACT_MASTER table$")
	public void given_data_is_in_received_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new RuntimeException("When is failing");
		/*
	    try {
			Assert.fail("dummy failure");
		}
		catch (AssertionError e) {
			Thread.sleep(1);
			System.out.println("Assert Failed in @When");
		} */
		ExcelOps.getConfig();
		//Check Test Data Status here..
	}

	
	
	@When("^Java Batch Engine processes provided Contract Codes$")
	public void when_Batch_Engine_processes_Contracts(Map<String, String> SelData) throws Throwable {

		//===SELENIUM CODE BLOCK STARTS ============================================================================
		WebDriver wd = selenium_init.SelDriverInit();
		
		String sheet = SelData.entrySet().stream().findFirst().get().getKey();   //Needs to be put into LOOP
		String TCnm  = SelData.entrySet().stream().findFirst().get().getValue(); //Needs to be put into LOOP
		
		//System.out.println(" TC Name and Sheet " + sheet + TCnm);
		//Thread.sleep(10000000);
		
		returnTD = ExcelOps.FetchTD(sheet, TCnm);
		System.out.println("FetchSelTD is Success");
		
		String cntrct = ""; String lastUsedCntrctCd = "";
		try {
		  for(int i=0; i<returnTD.length; i++) { //data table for loop
			if (returnTD[i][1].equals("same"))  {
				cntrct = lastUsedCntrctCd;
				System.out.println("Skipping as Test Data is same as Previous step.");
				continue; //move onto next data - only for Selenium step
			}
			else {
				cntrct = returnTD[i][1]; //test data column
				lastUsedCntrctCd = returnTD[i][1]; //preserve last used valid test data
			}

			if (cntrct == null)	
				break;
			else	{
				wd.get(ExcelOps.BatchEngineUrl); // Open URL
				//wd.get("http://vaathmr868:9092/mapengine"); // Open URL
				System.out.println("Opened URL & Passing Contract Code:" + cntrct);
				wd.manage().window().maximize();
			
				WebElement ContractCdTxtBox = wd.findElement(By.xpath("//*[@id=\"mbr-page-wrapper\"]/div[2]/div/table/tbody/tr[1]/td[2]/textarea"));   //xpath
				ContractCdTxtBox.sendKeys(cntrct);
				Thread.sleep(100);
				WebElement SendBtn = wd.findElement(By.xpath("//*[@id='submit']"));   //xpath: //*[@id="submit"]
				SendBtn.click();
				Thread.sleep(3000);
				
				WebElement message = wd.findElement(By.xpath("//*[@id='msg']")); //path: //*[@id="msg"]
				String msg = message.getText();
				System.out.println(msg);
			}
				
		  } // end for loop
		
		}
		catch (UnhandledAlertException e) {
			System.out.println("unexpected alert open: {Alert text : failure message: {data:null}}");
		}
		catch (NullPointerException e2) {
			System.out.println("Excel test data finished. Encountered Null row.");
		}
		finally {
			//System.out.println("Waiting 5 sec...");
			//Thread.sleep(5000);
			//System.out.println("Waited 5 sec before exit");
			System.out.println("========================  Finished WHEN section of TC1  ========================");
			wd.close();  // Close webdriver & browser
		}
	  


	}

	
	
	@Then("^Validate columns of RAW Input table CS90_CONTRACT_MASTER are moved to CS90_EHUB_PROD Table$")
	public void then_validate_ETL_in_database_layer(Map<String, String> sqlVsSqlList) throws Throwable {
		//sqlVsSqlList.forEach((k,v)->System.out.println("To_Run_Column : " + k + " SQL_Dump_File_Name : " + v));
		boolean tc_fail_flag = false;
		String msg = "";
		String TcNm = ""; String Tdata = ""; String SRCsql = ""; String TRGsql = ""; String lastUsedTdata = "";
		String fail_TcNm = ""; String fail_msg = "";
		//Database Section ==========================
		//Connection DbConn = database.db_conn();
		//ResultSet SRCrs = null; ResultSet TRGrs = null;
		//Database Section ==========================
		
		//Map<String, String> SQLMap;
		//SQLMap = ExcelOps.xlsFetchSQLpair();
		
		//-------------SPARK CONFIG ------------------
		sparkSess = SparkOps.SparkConn();
		Dataset<org.apache.spark.sql.Row> srcDF = null;
		Dataset<org.apache.spark.sql.Row> trgDF = null;
		//--------------------------------------------
		
		for(int i=0; i<returnTD.length; i++) { //Test data table for loop
		  try {
			if (returnTD[i][1].equals("same"))  {
				Tdata = lastUsedTdata;
				System.out.println("Skipping as Test Data is same as Previous step.");
				//continue; //move onto next data - only for Selenium step, not for DB step
			}
			else {
				Tdata  = returnTD[i][1]; //test data column
				lastUsedTdata = returnTD[i][1]; //preserve last used valid test data
			}
		  } catch (Exception e) {
				continue; //Null pointer expected
		  }
			TcNm   = returnTD[i][0];		
			SRCsql = returnTD[i][2];
			TRGsql = returnTD[i][3];
			if (SRCsql == null || TRGsql == null)	{
				break;
			}
			else	{
				try {
					//==== Exec SQL using plain JDBC =======
					//SRCrs = database.sql_exec(DbConn, SRCsql, Tdata); //SQL1
					//TRGrs = database.sql_exec(DbConn, TRGsql, Tdata); //SQL2
					
					//==== Exec SQL using SPARK =======
					srcDF = SparkOps.SparkSQLExec(sparkSess, SRCsql, Tdata); //SQL1-src-raw input
					trgDF = SparkOps.SparkSQLExec(sparkSess, TRGsql, Tdata); //SQL2-trg-raw output
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
			
			
			
			
			msg = SparkOps.SparkComparator(srcDF, trgDF);  //Compare result Sets
			if (msg.contains("SRC query has 0 extra rows than TRG query")) {
				System.out.println("Test Case is PASS");
			}
			else {
				tc_fail_flag = true;
				System.out.println("Test Case is FAIL");
				/*
				//working
				fail_TcNm = fail_TcNm + " " + TcNm + "\n";
				fail_msg = fail_msg + " " + msg + "\n";
				*/
				//fail_TcNm = fail_TcNm + " " + TcNm + "\n";
				fail_msg = fail_msg + "\nFailed TC = " + TcNm + "\nFailure Message = \n" + msg + "\n===================================================";
				
			}
			
			

		} // end for loop of Test Data table
		
		if (tc_fail_flag) {
			//Assert.fail("Failed Test Case(s) = \n" + fail_TcNm + "\nError Message(s) = \n" + fail_msg); // this works with JUPITER Reports
			//throw new RuntimeException("The two ResultSets contains different Values!");
			Assert.fail(fail_msg);
			System.out.println("Current Test Scenario Ends=======================================");
		}

		
	
		//sparkSess.close();
		//SparkOps.sc.close();
		//DbConn.close();
		System.out.println("Current Test Scenario Ends=======================================");
	}

	
	//TC2
	@Given("^Test Data is in RECEIVED state in CS(\\d+)_CONTRACT_MASTER table  for Complex Transformations$")
	public void test_Data_is_in_RECEIVED_state_in_CS__CONTRACT_MASTER_table_for_Complex_Transformations(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@When("^Java Batch Engine processes provided Contract Codes for Complex Transformations$")
	public void java_Batch_Engine_processes_provided_Contract_Codes_for_Complex_Transformations(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    //throw new PendingException();
	}

	@Then("^Validate columns of RAW Input table CS90_CONTRACT_MASTER are moved to CS90_EHUB_PROD Table for Complex Transformations$")
	public void then_validate_ETL_in_database_layerTC2(DataTable arg1) throws Throwable {

	}

	
	
	
	//===========================================================================================================
	//TC 3
	//Scenario: Automated validation of CS90 Contract codes being Processed within 5 minutes by Java Batch Engine
	
	@Given("^Read Test Data from Input Excel which is in RECEIVED state at RAW INPUT Tables$")
	public void read_Test_Data_from_Input_Excel_which_is_in_RECEIVED_state_at_RAW_INPUT_Tables(Map<String, String> data) throws Throwable {
		ExcelOps.getConfig();
		String sheet = data.entrySet().stream().findFirst().get().getKey();   //Needs to be put into LOOP
		String TCnm  = data.entrySet().stream().findFirst().get().getValue(); //Needs to be put into LOOP
		
		//Fetch Data from Excel START =========
		returnTD = ExcelOps.FetchTD(sheet, TCnm);
		System.out.println("TC3 = FetchSelTD is Success");
		//Fetch Data from Excel END   =========
		
	}

	@When("^Java Batch Engine processes provided Contract Codes note down the time$")
	public void java_Batch_Engine_processes_provided_Contract_Codes_note_down_the_time() throws Throwable {
		System.out.println("TC3 = Java Batch Engine processes provided Contract Codes - Start");
		WebDriver wd = selenium_init.SelDriverInit();
		
		//Note down start time
		javaBatchProcessTime = new Date();
		
		try {
			  for(int i=0; i<returnTD.length; i++) { // data table for loop
				String cntrct = returnTD[i][1];      // 1 = test data column
				if (cntrct == null)
					break;
				else	{
					wd.get(ExcelOps.BatchEngineUrl); // Open URL
					//wd.get("http://vaathmr868:9092/mapengine"); // Open URL
					System.out.println("Opened URL & Passing Contract Code:" + cntrct);
					wd.manage().window().maximize();
					
					WebElement ContractCdTxtBox = wd.findElement(By.xpath("//*[@id=\"mbr-page-wrapper\"]/div[2]/div/table/tbody/tr[1]/td[2]/textarea"));   //xpath
					ContractCdTxtBox.sendKeys(cntrct);
					Thread.sleep(100);
					WebElement SendBtn = wd.findElement(By.xpath("//*[@id='submit']"));   //xpath: //*[@id="submit"]
					SendBtn.click();
					Thread.sleep(3000);
					
					WebElement message = wd.findElement(By.xpath("//*[@id='msg']")); //path: //*[@id="msg"]
					String msg = message.getText();
					System.out.println(msg);
				}
			
			  } // end for loop
			
			}
			catch (UnhandledAlertException e) {
				System.out.println("unexpected alert open: {Alert text : failure message: {data:null}}");
			}
		
		System.out.println("===============  EXIT WHEN OF TC3 ===============");
		wd.close();
	}

	@Then("^Validate that the SUCCESSful records are processed to RAW Output tables within (\\d+) minutes$")
	public void validate_that_the_SUCCESSful_records_are_processed_to_RAW_Output_tables_within_minutes(int timeThreshold) throws Throwable {
		//-------------SPARK CONFIG -------------------
		sparkSess = SparkOps.SparkConn();
		Dataset<org.apache.spark.sql.Row> timeStampDF = null;
		//Dataset<org.apache.spark.sql.Row> maxTimeDF = null;
		//---------------------------------------------
		
		String TcNm = ""; String Tdata = ""; 
		//String sql = "select max(last_updt_dtm) from EHUB_PROD_RAW.cs90_ehub_prod where cntrct_cd IN replace(?,'-','')";  //Query to pull LAST UPD
		String sql = "select * from ( select * from ( select max(last_updt_dtm) as updt, 'cs90_ehub_prod' as tblnm from EHUB_PROD_RAW.cs90_ehub_prod where cntrct_cd in  replace(?,'-','') union select max(last_updt_dtm) as updt, 'cs90_ehub_prod_atrb' as tblnm  from EHUB_PROD_RAW.cs90_ehub_prod_atrb where cntrct_cd in  replace(?,'-','') union select max(last_updt_dtm) as updt, 'cs90_ehub_prod_plan' as tblnm from EHUB_PROD_RAW.cs90_ehub_prod_plan where cntrct_cd in  replace(?,'-','')   union select max(last_updt_dtm) as updt, 'cs90_ehub_plan' as tblnm  from EHUB_PROD_RAW.cs90_ehub_plan where Replace(PLAN_PRXY_ID,'-M','') in (?) ) src order by updt desc ) src1 where rownum =1"; 
		
		String fail_TcNm = ""; String fail_msg = "";
		//System.out.println("--->> returnTD"+returnTD);
		
		for(int i=0; i<returnTD.length; i++) { //Test data table for loop
			TcNm   = returnTD[i][0];
			Tdata  = returnTD[i][1];
			//System.out.println("---Tdata>> "+Tdata);
			//System.out.println("**********START*************");
	
			if (null == Tdata || Tdata.equals("")) {
				break;
			}
			else {
				try 	{					
					timeStampDF = SparkOps.SparkSQLExec(sparkSess, sql, Tdata); //Last Upd checking query
							//maxTimeDF = maxTimeDF.union(srcDF);
							timeStampDF.show();
						} catch (Exception e) {
							//e.printStackTrace();
						}
					
				}
			//System.out.println("**********END*************");
		}
		List<String> rawOpTSlist = timeStampDF.map(row -> row.mkString(), Encoders.STRING()).collectAsList();     //pick only first column WIP WIP WIP **********
		String rawOpLoadTS = String.join(",", rawOpTSlist);
		Date parsedDBTS = TsFormat.parse(rawOpLoadTS);
		System.out.println("Last UPD from DB as STRING is: " + parsedDBTS);
		//System.out.println("Last UPD from Java Batch as STRING is: " + javaBatchProcessTime);
		
		//parsedDBTS = new Date(); //for mocked up TS after validation, to hit Pass scenario
		// below lines for unit testing =====
		//Calendar cal = Calendar.getInstance();
		//cal.setTime(parsedDBTS);
		//cal.add(Calendar.DATE, 10); // add 10 days
		//parsedDBTS = cal.getTime();
		// unit testing  ends above =====
		
		long diffInMillies = 0;
		long diff = 0;
		if (parsedDBTS.getTime() > javaBatchProcessTime.getTime()) {  //If DB has later update TS than Java Batch Engine
			diffInMillies = Math.abs(parsedDBTS.getTime() - javaBatchProcessTime.getTime());
			diff = TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);
			//System.out.println("Difference between Java Batch and SQL Update is: " + diff);
		}
		else {
			Assert.fail("\nTest Case FAIL - DB Last Update Timestamp is OLDER than Java Batch Timestamp.\nMake sure you are Pushing Test Data of RECEIVED state.\nIt seems this Contract was processed Earlier.\n");
		}
		
		
		if (diff > timeThreshold) { //If Time Diff is less than threshold mentioned in Feature File's THEN
			Assert.fail("\nTest Case FAIL - Contract Code processing from Java Batch Engine to RAW Output Layer took more than " + timeThreshold + " minutes.\nExpected time Threshold = " + timeThreshold + " mins.\nActual time taken = " + diff + " mins.\nWorst performing table is:\n" + rawOpTSlist);
		}
		else {
			System.out.println("TC3 is PASS.\nLoad time from Java Batch to DB is less than or equal to Threshold of " + timeThreshold + " mins.\n");
		}
		
		
		
	System.out.println("===============  EXIT THEN OF TC3 ===============");	
	}
	
	
	//TC-CS90-BNFT_CMPNT
	@Given("^Read Test Data from Input Excel for this test case$")
	public void read_Test_Data_from_Input_Excel_for_this_test_case(Map<String, String> data) throws Throwable {
		ExcelOps.getConfig();
		String sheet = data.entrySet().stream().findFirst().get().getKey();   //Needs to be put into LOOP
		String TCnm  = data.entrySet().stream().findFirst().get().getValue(); //Needs to be put into LOOP
		
		//Fetch Data from Excel START =========
		returnTD = ExcelOps.FetchTD(sheet, TCnm);
		//System.out.println("TC3 = FetchSelTD is Success");
	}

	@When("^Data is processed from CS(\\d+)_MASTER_MAPPING to CS(\\d+)_EHUB_BNFT_CMPNT table$")
	public void data_is_processed_from_CS__MASTER_MAPPING_to_CS__EHUB_BNFT_CMPNT_table(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@Then("^Validate that all the records are Loaded into CS90_EHUB_BNFT_CMPNT table as per ETL rules$")
	public void validate_that_all_the_records_are_Loaded_into_CS__EHUB_BNFT_CMPNT_table_as_per_ETL_rules(Map<String, String> sqlVsSqlList) throws Throwable {
		//sqlVsSqlList.forEach((k,v)->System.out.println("To_Run_Column : " + k + " SQL_Dump_File_Name : " + v));
				boolean tc_fail_flag = false;
				String msg = "";
				String TcNm = ""; String Tdata = ""; String SRCsql = ""; String TRGsql = ""; String lastUsedTdata = "";
				String fail_TcNm = ""; String fail_msg = "";
				
				//-------------SPARK CONFIG ------------------
				sparkSess = SparkOps.SparkConn();
				Dataset<org.apache.spark.sql.Row> srcDF = null;
				Dataset<org.apache.spark.sql.Row> trgDF = null;
				//--------------------------------------------
				
				for(int i=0; i<returnTD.length; i++) { //Test data table for loop
				  try {
					if (returnTD[i][1].equals("same"))  {
						Tdata = lastUsedTdata;
						System.out.println("Skipping as Test Data is same as Previous step.");
					}
					else {
						Tdata  = returnTD[i][1]; //test data column
						lastUsedTdata = returnTD[i][1]; //preserve last used valid test data
					}
				  } catch (Exception e) {
						continue; //Null pointer expected
				  }
					TcNm   = returnTD[i][0];		
					SRCsql = returnTD[i][2];
					TRGsql = returnTD[i][3];
					if (SRCsql == null || TRGsql == null)	{
						break;
					}
					else	{
						try {
							srcDF = SparkOps.SparkSQLExec(sparkSess, SRCsql, Tdata); //SQL1-src-raw input
							trgDF = SparkOps.SparkSQLExec(sparkSess, TRGsql, Tdata); //SQL2-trg-raw output
						
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				
					msg = SparkOps.SparkComparator(srcDF, trgDF);  //Compare result Sets
					if (msg.contains("SRC query has 0 extra rows than TRG query")) {
						System.out.println("Test Case is PASS");
					}
					else {
						tc_fail_flag = true;
						System.out.println("Test Case is FAIL");
						fail_msg = fail_msg + "\nFailed TC = " + TcNm + "\nFailure Message = \n" + msg + "\n===================================================";
						
					}
				} // end for loop of Test Data table
				
				if (tc_fail_flag) {
					Assert.fail(fail_msg);
				}

		
		
		
		System.out.println("===============  EXIT THEN OF TC-CS90-BNFT_CMPNT ===============");
	}


}
