package ehub_benefits;

import java.io.FileWriter;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.openqa.selenium.UnhandledAlertException;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;

public class SparkOps {
	static JavaSparkContext sc = null;
	
	public SparkOps() {
		
		
	}
	
	
	
	public static SparkSession SparkConn() throws ClassNotFoundException, InterruptedException {
		System.out.println("Firing up Apache Spark...");
		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);
		Logger.getLogger("spark").setLevel(Level.OFF);

		System.setProperty("hadoop.home.dir", "C:\\Hadoop");
		
		if(null == sc){
			sc = new JavaSparkContext(new SparkConf().setAppName("SparkJdbcDs").setMaster("local[*]"));
			SQLContext sqlContext = new SQLContext(sc);
		}
		SparkSession sparkSess = SparkSession.builder().appName("My Spark App").getOrCreate();
		System.out.println("Spark Session is built, returning to Caller method...");
		return sparkSess;
	}
	
	
	
	public static Dataset<Row> SparkSQLExec(SparkSession SparkSes, String Sql, String Tdata) throws ClassNotFoundException, InterruptedException {
		System.out.println("Came within SparkSQLExec Method with test data = " + Tdata);

		//Sql = "sparkour.people";
		//Sql = "select * from EHUB_PROD_RAW.cs90_ehub_prod where rownum < 11";
		
		Properties connectionProperties = new Properties(); //For SPARK connection properties
		connectionProperties.put("user", ExcelOps.DBUser);
		connectionProperties.put("password", ExcelOps.DBpw);
		Dataset<Row> jdbcDF = null;
		
		if (Sql.contains("?")) { //IF preparedStatement-----------------------------------------
			//System.out.println("Test Data passed: " + Tdata);
			Tdata = Tdata.replaceAll("\\s","");
			Tdata = Tdata.replaceAll(",", "','");
			Tdata = "'" + Tdata + "'";
			//System.out.println("Test Data after editing: " + Tdata);
			Sql = Sql.replaceAll("\\?",Tdata);
			Sql = "(" + Sql + ")";
			//System.out.println("======================================================");
			//System.out.println("Going to Execute Prep Stmt : " + Sql);
			try {
				jdbcDF = SparkSes.read().jdbc(ExcelOps.jdbcUrl, Sql, connectionProperties);
				//jdbcDF.show();
				//System.out.println("Prep Stmt Executed: " + Sql);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		else { //ELSE IF NOT preparedStatement---------------------------------------------
			Sql = "(" + Sql + ")";
			try {
				//System.out.println("--SparkSes>>"+SparkSes);
				//System.out.println("--Sql>>"+Sql);
				//System.out.println("--connectionProperties>>"+connectionProperties);
				//System.out.println("--ExcelOps.jdbcUrl>>"+ExcelOps.jdbcUrl);
				System.out.println("SQL Stmt Going To Be Executed: " + Sql);
				jdbcDF = SparkSes.read().jdbc(ExcelOps.jdbcUrl, Sql, connectionProperties);
				//jdbcDF.show();
				System.out.println("SQL Stmt Executed: " + Sql);
			} 	catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		//Thread.sleep(500);
		
		//sparkSess.close();
		//context.close();
		
		return jdbcDF;
	}
	
	public static String SparkComparator(Dataset<Row> df1, Dataset<Row> df2) throws ClassNotFoundException, InterruptedException {
		System.out.println("================== Spark Comparator Starts ========================");
		String msg = "";
		Dataset<Row> srcDFbkp = df1;
		Dataset<Row> trgDFbkp = df2;
		Dataset<Row> aMINUSbDF; Dataset<Row> bMINUSaDF;
		
		//--Step 1: SRC MINUS TRG -------------------
		aMINUSbDF = df1.except(df2);
		List<String> listOne = aMINUSbDF.limit(30).map(row -> row.mkString(), Encoders.STRING()).collectAsList();
		String srcOpStr = String.join("\n", listOne);
		//aMINUSbDF.show();
		long rowCnt = aMINUSbDF.count();
		//Thread.sleep(1);		
		msg = msg + "SRC query has "+ rowCnt + " extra rows than TRG query \n";
		//--Step 2: TRG MINUS SRC -------------------
		df1 = srcDFbkp;
		df2 = trgDFbkp;
		bMINUSaDF = df2.except(df1);
		List<String> listTwo = bMINUSaDF.limit(30).map(row -> row.mkString(), Encoders.STRING()).collectAsList();
		String trgOpStr = String.join("\n", listTwo);
		//bMINUSaDF.show();
		rowCnt = bMINUSaDF.count();
		//Thread.sleep(1);
		msg = msg + "TRG query has "+ rowCnt + " extra rows than SRC query \n";
		msg = msg + "Extra in SRC : \n" + srcOpStr;
		msg = msg + "\nExtra in TRG : \n" + trgOpStr;
		System.out.println(msg);
		System.out.println("================= Spark Comparator Ends ======================");
		return msg;
		
		/*
		data.foreach(new ForeachFunction<Row>() {
            public void call(Row arg0) throws Exception {
                System.out.println(arg0);
            }
        });
        */
	}
	
	

}
